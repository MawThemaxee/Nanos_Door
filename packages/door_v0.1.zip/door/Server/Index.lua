Package.Require("HingeDoor.lua")
Package.Require("SlidingDoor.lua")

-- Example doors spawned on package load; call HingeDoor(...) / SlidingDoor(...)
-- again per additional door placement. Trailing args on each are optional:
-- door_asset (mesh) falls back to BaseDoor.DEFAULT_MESH_ASSET, door_scale
-- falls back to the door type's own DEFAULT_SCALE.
HingeDoor(Vector(0, 0, 100), Rotator(0, 0, 90))
SlidingDoor(Vector(300, 0, 100), Rotator())

-- Runtime modification + lock example: every BaseDoor exposes SetDoorAsset()
-- / SetDoorScale() / SetDoorMaterial(), and Lock() / Unlock() / IsLocked().
local locked_door = HingeDoor(Vector(600, 0, 100), Rotator(0, 0, 90), "nanos-world::SM_Cube", Vector(2, 3, 1.5))
locked_door:Lock()
